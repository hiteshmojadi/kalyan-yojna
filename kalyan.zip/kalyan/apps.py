from django.apps import AppConfig


class KalyanConfig(AppConfig):
    name = 'kalyan'
